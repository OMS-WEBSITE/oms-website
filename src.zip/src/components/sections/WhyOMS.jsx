// import React from "react";

// const WhyOMS = () => {
//   return (
//     <section id="why-oms" className="py-16 sm:py-24 bg-gray-50">
//       <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
//         {/* Title */}
//         <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-gray-800 mb-4 sm:mb-6">
//           <span className="border-b-4 border-orange-500 pb-1">Why OMS</span>
//         </h2>

//         {/* Intro text */}
//         <p className="max-w-2xl mx-auto text-gray-600 text-sm sm:text-base leading-relaxed mb-8">
//           Learn why businesses trust OMS for seamless workflow and technology solutions.
//         </p>

//         {/* Headline */}
//         <h3 className="text-xl sm:text-2xl font-semibold text-gray-800 mb-4">
//           Designed with auditors - trusted by labs.
//         </h3>

//         {/* Body */}
//         <p className="max-w-3xl mx-auto text-gray-700 text-sm sm:text-base leading-relaxed mb-6 px-2 sm:px-0">
//           OMS Software unites <strong>LIMS</strong>, <strong>ERP</strong>, and <strong>QMS</strong> into one secure platform.
//           Labs use it to stay compliant, deliver faster, and maintain long-term traceability without manual effort.
//         </p>

//         {/* Divider line */}
//         <div className="h-0.5 w-20 bg-orange-500 mx-auto my-6"></div>

//         {/* Trust statement */}
//         <p className="max-w-3xl mx-auto text-gray-700 text-sm sm:text-base leading-relaxed px-2 sm:px-0">
//           OMS is a proud member of the <strong>Indian Society for Non-Destructive Testing (ISNT)</strong> and the{" "}
//           <strong>American Society for Nondestructive Testing (ASNT)</strong>.
//           These affiliations reflect our ongoing commitment to uphold international standards and contribute to the NDT
//           community’s digital transformation.
//         </p>
//       </div>
//     </section>
//   );
// };

// export default WhyOMS;

import React from "react";

const WhyOMS = () => {
  return (
    <section
      className="min-h-screen bg-white py-10 sm:py-16 md:py-20"
      id="why-oms"
    >
      <div className="w-[90%] mx-auto py-4 px-2 text-center">
        {/* Title */}
        <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-gray-800 mb-4 sm:mb-6">
          <span className="border-b-4 border-orange-500 pb-1">🌐 Why OMS</span>
        </h2>

        {/* Intro */}
        <h3 className="text-xl sm:text-2xl font-semibold text-gray-800 mb-4">
          Built with auditors. Trusted by laboratories.
        </h3>

        {/* Story / Description */}
        <p className="max-w-4xl mx-auto text-gray-700 text-sm sm:text-base leading-relaxed mb-6">
          It began with a familiar frustration - labs buried under spreadsheets,
          versioned PDFs, and last-minute audit prep. Each tool solved a
          fragment of the problem, but none spoke to the whole workflow. So OMS
          was built - a single, secure system that unites <strong>LIMS</strong>,{" "}
          <strong>ERP</strong>, and <strong>QMS</strong>, the way laboratories
          actually operate.
        </p>

        <p className="max-w-4xl mx-auto text-gray-700 text-sm sm:text-base leading-relaxed mb-6">
          Over the years, OMS has grown into more than software. It’s become a
          bridge between compliance and convenience - trusted by auditors,
          valued by managers, and relied on by teams who want their systems to
          stay out of the way and just work.
        </p>

        {/* Divider */}
        <div className="h-0.5 w-20 bg-orange-500 mx-auto my-6"></div>

        {/* Highlights */}
        <div className="text-left max-w-4xl mx-auto space-y-8 text-gray-700 text-sm sm:text-base">
          <div>
            <h4 className="text-lg font-semibold text-orange-600 mb-2">
              🧩 One Platform for Every Process
            </h4>
            <p>
              Testing, calibration, logistics, invoicing, quality - everything
              flows together. One login, one live record of truth.
            </p>
          </div>

          <div>
            <h4 className="text-lg font-semibold text-orange-600 mb-2">
              🔒 Compliance Built In
            </h4>
            <p>
              Automatic ISO/IEC 17025 | 17020 | 9001 audit trails capture every
              action and signature - so the next audit feels like a
              confirmation, not a chase.
            </p>
          </div>

          <div>
            <h4 className="text-lg font-semibold text-orange-600 mb-2">
              ⚙️ Designed with Auditors
            </h4>
            <p>
              We co-created OMS with QA managers, NABL assessors, and engineers
              who know the process inside out. Every feature has a reason.
            </p>
          </div>

          <div>
            <h4 className="text-lg font-semibold text-orange-600 mb-2">
              📈 Faster Workflows
            </h4>
            <p>
              Automation trims the steps between quotation, testing, and report
              delivery. ULR + QR verification keeps every report authentic and
              instantly verifiable.
            </p>
          </div>

          <div>
            <h4 className="text-lg font-semibold text-orange-600 mb-2">
              🧾 Ten-Year Traceability
            </h4>
            <p>
              Every report, certificate, and approval stays preserved and
              searchable for a decade - even after subscription expiry. Clients
              retain secure access to what matters.
            </p>
          </div>

          <div>
            <h4 className="text-lg font-semibold text-orange-600 mb-2">
              🤝 Grounded in Global Standards
            </h4>
            <p>
              OMS is built around internationally recognized frameworks such as
              ISO/IEC 17025, ISO 9001, and relevant ASTM and ASME standards -
              helping your lab maintain compliance and consistency across every
              test and report.
            </p>
          </div>
        </div>

        {/* Divider */}
        <div className="h-0.5 w-20 bg-orange-500 mx-auto my-8"></div>

        {/* Conclusion */}
        <p className="max-w-4xl mx-auto text-gray-700 text-sm sm:text-base leading-relaxed">
          <strong>The result:</strong> Labs no longer juggle systems or chase
          records. They operate with clarity, speed, and proof - powered by OMS.
        </p>
      </div>
    </section>
  );
};

export default WhyOMS;
