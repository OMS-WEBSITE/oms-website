import React from "react";
import HeaderWithContent from "../layout/HeaderWithContent.jsx";

const ProductsandService = () => {
  return (
    <section id="productsandservice" className="bg-white-50">
      <HeaderWithContent/>
    </section>
  );
};

export default ProductsandService;
